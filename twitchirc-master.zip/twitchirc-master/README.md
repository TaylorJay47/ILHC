# TwitchIRC
All rights reserved © 2016 Twitch Interactive, Inc.

## Light-TwitchIRC
This is a modified version, this version is lighter sacrificing the "User" and "Channel" objects.  
[![Download TwitchIRC](https://img.shields.io/badge/Light--TwitchIRC-v1.1-yellowgreen.svg)](https://github.com/cavariux/TwitchIRC/releases/download/Light_v1.1-Beta/Light-TwitchIRC_v1.1-Beta.jar)

***

If You want to learn about how to use the Library visit the [Wiki](https://github.com/cavariux/TwitchIRC/wiki)!                      

[![Download TwitchIRC](https://img.shields.io/badge/TwitchIRC-v1.2-green.svg?style=plastic)](https://github.com/cavariux/TwitchIRC/releases/download/v1.2/TwitchIRC_v1.2.jar) 
[![GitHub license](https://img.shields.io/github/license/mashape/apistatus.svg?style=plastic)](https://github.com/CavariuX/TwitchIRC/blob/master/LICENSE) 
[![Documentation](https://img.shields.io/badge/Documentation-v1.1-orange.svg?style=plastic)](http://cavariux.github.io/TwitchIRC/) 

***

If you think you can make an optimization feel free to make a fork. In that fork make all modifications you need an then on this page go to pull requests and make a request. Thanks.

***

Build the project with gradle using `> gradle fatjar`. The jar can then be found in `<projectroot>\build\libs\`

***
Please support us by sharing this library and hitting that star button. Thank you.
